const API = "/api";

async function fetchJson(url, options) {
  const res = await fetch(url, options);
  if (!res.ok && res.status !== 204) throw new Error(await res.text());
  return res.status === 204 ? null : res.json();
}

// ---------- STUDENTS ----------
async function loadStudents() {
  const students = await fetchJson(`${API}/students`);
  const tbody = document.querySelector("#studentTable tbody");
  tbody.innerHTML = "";
  const select = document.querySelector("#enrollStudent");
  select.innerHTML = "";
  students.forEach(s => {
    tbody.innerHTML += `<tr>
      <td>${s.id}</td><td>${s.name}</td><td>${s.email}</td><td>${s.phone ?? ""}</td>
      <td><button class="delete-btn" onclick="deleteStudent(${s.id})">Delete</button></td>
    </tr>`;
    select.innerHTML += `<option value="${s.id}">${s.name}</option>`;
  });
}

document.querySelector("#studentForm").addEventListener("submit", async e => {
  e.preventDefault();
  const body = {
    name: document.querySelector("#studentName").value,
    email: document.querySelector("#studentEmail").value,
    phone: document.querySelector("#studentPhone").value
  };
  await fetchJson(`${API}/students`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  e.target.reset();
  await loadStudents();
  await loadEnrollments();
});

async function deleteStudent(id) {
  await fetchJson(`${API}/students/${id}`, { method: "DELETE" });
  await loadStudents();
  await loadEnrollments();
}

// ---------- COURSES ----------
async function loadCourses() {
  const courses = await fetchJson(`${API}/courses`);
  const tbody = document.querySelector("#courseTable tbody");
  tbody.innerHTML = "";
  const select = document.querySelector("#enrollCourse");
  select.innerHTML = "";
  courses.forEach(c => {
    tbody.innerHTML += `<tr>
      <td>${c.id}</td><td>${c.title}</td><td>${c.instructor ?? ""}</td><td>${c.credits ?? ""}</td>
      <td><button class="delete-btn" onclick="deleteCourse(${c.id})">Delete</button></td>
    </tr>`;
    select.innerHTML += `<option value="${c.id}">${c.title}</option>`;
  });
}

document.querySelector("#courseForm").addEventListener("submit", async e => {
  e.preventDefault();
  const body = {
    title: document.querySelector("#courseTitle").value,
    instructor: document.querySelector("#courseInstructor").value,
    credits: Number(document.querySelector("#courseCredits").value) || null
  };
  await fetchJson(`${API}/courses`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  e.target.reset();
  await loadCourses();
  await loadEnrollments();
});

async function deleteCourse(id) {
  await fetchJson(`${API}/courses/${id}`, { method: "DELETE" });
  await loadCourses();
  await loadEnrollments();
}

// ---------- ENROLLMENTS ----------
async function loadEnrollments() {
  const enrollments = await fetchJson(`${API}/enrollments`);
  const tbody = document.querySelector("#enrollTable tbody");
  tbody.innerHTML = "";
  enrollments.forEach(en => {
    tbody.innerHTML += `<tr>
      <td>${en.id}</td>
      <td>${en.student?.name ?? "-"}</td>
      <td>${en.course?.title ?? "-"}</td>
      <td>${en.enrolledOn ?? ""}</td>
      <td>${en.grade ?? "-"}</td>
      <td><button class="delete-btn" onclick="deleteEnrollment(${en.id})">Remove</button></td>
    </tr>`;
  });
}

document.querySelector("#enrollForm").addEventListener("submit", async e => {
  e.preventDefault();
  const body = {
    studentId: Number(document.querySelector("#enrollStudent").value),
    courseId: Number(document.querySelector("#enrollCourse").value)
  };
  await fetchJson(`${API}/enrollments`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  await loadEnrollments();
});

async function deleteEnrollment(id) {
  await fetchJson(`${API}/enrollments/${id}`, { method: "DELETE" });
  await loadEnrollments();
}

// ---------- INIT ----------
(async function init() {
  await loadStudents();
  await loadCourses();
  await loadEnrollments();
})();
